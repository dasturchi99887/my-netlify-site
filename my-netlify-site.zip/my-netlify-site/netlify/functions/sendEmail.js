const nodemailer = require('nodemailer');

exports.handler = async (event) => {
    const { name, email, message } = JSON.parse(event.body);

    // Nodemailer konfiguratsiyasi
    const transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
            user: process.env.EMAIL, // .env faylidan email
            pass: process.env.EMAIL_PASSWORD, // .env faylidan parol
        },
    });

    const mailOptions = {
        from: process.env.EMAIL,
        to: process.env.EMAIL, // Xabarni o'zingizga yuborish
        subject: `Yangi xabar: ${name}`,
        text: `Ism: ${name}\nEmail: ${email}\nXabar: ${message}`,
    };

    try {
        await transporter.sendMail(mailOptions);
        return {
            statusCode: 200,
            body: JSON.stringify({ message: 'Xabar muvaffaqiyatli yuborildi!' }),
        };
    } catch (error) {
        return {
            statusCode: 500,
            body: JSON.stringify({ error: 'Xabar yuborishda xatolik yuz berdi.' }),
        };
    }
};